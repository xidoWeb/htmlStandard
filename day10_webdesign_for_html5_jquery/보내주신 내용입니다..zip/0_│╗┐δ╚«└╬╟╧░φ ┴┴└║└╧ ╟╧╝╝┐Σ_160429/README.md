# html내용정리
> 제가 사용하고 있는 reset.css파일을 첨부하여드립니다.
실제로는 reset.css/common.css로 분류하여 사용하고 
normalize.css 파일에 담아 사용하고 있습니다.
약간의 속도저하는 있지만 수강생분들에게 정확한 의미를 부여하고 왜 그렇게 사용하는지 알려줄 수 있기 때문입니다.

> normalize.css파일을 열어보시면 아시겠지만
상단에 css파일 사용시 기준을 잡는 내용들을 정리해 놓았습니다.
개인적으로 에릭마이어, 보일러플레이트, 네이버, 다음에서 사용하고있는 reset을 참고하여 제작하였습니다.
저에게 맞는 내용으로 커스텀하였기 때문에 조금 다른 부분도 있습니다.

### normalize.css
 * id는 camelcase 방식(뒤에오는 단어 첫글자 대문자)으로 하며, 
 * class는 underscore 방식(단어구분_)으로 사용한다.
 * 초기화 문서의 경우 reset.css로 별도 등록( @import url("./reset.css"); ) 한다.
 * 기본 반복 사용하는 형식의경우 common.css로 별도 등록( @import url("./common.css"); )하며, 
 * 개인의 경우 앞에 " me_ "를 붙여구분이 용이하도록 하여 사용한다.
 * id는 문서 내 한 번만 사용되며, id, class naming은 가급적 같지 않게 naming 한다.
 * 단, form영역에서는 구분이 용이하도록 맞춘다.
 * 별도의 네이밍 기법은 다음의 표준을 따른다. http://darum.daum.net/convention/name
 
```html
	<div id="firstBox">
		<ul class="first_in_box">
			<li class="first_in_01"></li>
			<li class="first_in_02"></li>
			<li class="first_in_03"></li>
			<li class="first_in_04"></li>
			<li class="first_in_05"></li>
		</ul>
	</div>
	<div id="secondBox">
		<ul class="first_in_box">
			<li class="first_in_01"></li>
			<li class="first_in_02"></li>
			<li class="first_in_03"></li>
			<li class="first_in_04"></li>
			<li class="first_in_05"></li>
		</ul>
	</div>
```

___
### 색상표기방법
 * 색상표기방법: webRGB 기법으로 처리, 투명도 처리시 RGBA()기법으로 처리하여 통일성을 지킨다.
 * 기본 글씨색: #333
 * 링크: #777 => hover: #0af
 * focus: line- 1px solid #fa0; box-sizing:border-box; background-color:#cdf;
 * input[type="text"]일 경우 text-indent:5px; (0.0625rem)을 처리한다.
___ 
### 접근성기준
 * 4.5:1 이상일경우는 기본폰트 12pt(1rem)으로 하되, 
 * 3:1일경우에는 18pt(1.5rem) or 14pt bold(1.16667rem), 
 * 최소폰트 9pt(0.75rem)을 처리한다.
___
### ir기법 적용시
 * 숨길텍스트 사용시 span으로 숨김 처리하며, 
 * width:0; height:0; display:block; overflow:hidden;으로 처리한다.
___ 
### is기법 적용시
 * background-position을 기본적으로 세로형으로 맞춰 사용한다.(상황에 따라 조금씩 다른형태로 사용)
 * 마우스:hover시에는 별도의 파일로 (끝에_on을 적용)사용하여 코드의 작성을 줄인다.
___
### float 버그 문제시
 * 1. 감싸는 부모태그에 .clearfix를 적용시켜 float 버그를 처리한다.
 * 2. 마지막단에 <br /> 태그를 사용하여 .clearfix 처리한다.
___ 
### double margin 문제시
 * margin-top사용시 부모태그와 함께 내려오는 문제를 해결하기위해선
 * 부모태그를 padding-top으로 처리한다.
